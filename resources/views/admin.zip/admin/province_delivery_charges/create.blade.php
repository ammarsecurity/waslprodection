@extends('layouts.app')
@section('header-title', 'إضافة محافظة جديدة')
@section('content')
<div class="container">
    <h2 class="mb-4">إضافة محافظة جديدة</h2>
    <form action="{{ route('admin.province_delivery_charges.store') }}" method="POST">
        @csrf
        <div class="form-group mb-3">
            <label for="province_name">اسم المحافظة</label>
            <input type="text" name="province_name" id="province_name" class="form-control" required>
        </div>
        <div class="form-group mb-3">
            <label for="delivery_charge">سعر التوصيل</label>
            <input type="number" name="delivery_charge" id="delivery_charge" class="form-control" step="0.01" min="0" required>
        </div>
        <button type="submit" class="btn btn-success">حفظ</button>
        <a href="{{ route('admin.province_delivery_charges.index') }}" class="btn btn-secondary">إلغاء</a>
    </form>
</div>
@endsection
