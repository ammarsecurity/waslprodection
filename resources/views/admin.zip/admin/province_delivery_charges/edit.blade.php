@extends('layouts.app')
@section('header-title', 'تعديل المحافظة')
@section('content')
<div class="container">
    <h2 class="mb-4">تعديل المحافظة</h2>
    <form action="{{ route('admin.province_delivery_charges.update', $charge->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="form-group mb-3">
            <label for="province_name">اسم المحافظة</label>
            <input type="text" name="province_name" id="province_name" class="form-control" value="{{ $charge->province_name }}" required>
        </div>
        <div class="form-group mb-3">
            <label for="delivery_charge">سعر التوصيل</label>
            <input type="number" name="delivery_charge" id="delivery_charge" class="form-control" step="0.01" min="0" value="{{ $charge->delivery_charge }}" required>
        </div>
        <button type="submit" class="btn btn-success">تحديث</button>
        <a href="{{ route('admin.province_delivery_charges.index') }}" class="btn btn-secondary">إلغاء</a>
    </form>
</div>
@endsection
